//////////////////////////////////////////////////////////////////////////
//
//  CGI Testing Example
//
//  Copyright (C) 1998 RIT Research Labs
//
//  This is a sample 'Hello World' program, where 'Hello' is printed
//  from a perl script and 'World' is printed from an executable written in
//  C and invoked from the perl script.
//
//////////////////////////////////////////////////////////////////////////

#include <stdio.h>

void main(void)
{
  printf("World\n");
}
